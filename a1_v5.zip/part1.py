import numpy as np
from tuning import ModelTuner

class CustomRegression:
    def __init__(self,**kwargs):
        self.params = {'max_epochs':1000,'learning_rate':0.01,'tolerance':0.001,'tol_epochs':5}
        for k in self.params:
            if k in kwargs:
                self.params[k] = kwargs[k]
        self.learning_rate = self.params['learning_rate']
        self.max_epochs = self.params['max_epochs']
        self.tolerance = self.params['tolerance']
        self.tol_epochs = self.params['tol_epochs']
        self.w = None

    def __repr__(self):
        return '<CustomRegression object: ' \
                'Parameters ' + str(self.params) + ', Weights ' + str(list(self.w.ravel())) + '>'
    def mse(self,X,y):
        return np.sum((X.dot(self.w) - y)**2) / 2*len(y)

    def gradient_descent(self,X,y):
        e,t,prev_loss = 0,0,0
        while e < self.max_epochs and t < self.tol_epochs:
            loss = self.mse(X,y)
            grad = X.T.dot(X.dot(self.w) - y) / len(y)
            self.w = self.w - self.learning_rate * grad
            t = t+1 if abs(loss-prev_loss) < self.tolerance else 0
            e = e+1
            prev_loss = loss
        self.actual_epochs = e

    def fit(self,X,y):
        X = np.append(np.ones((X.shape[0],1)),X,axis=1)
        self.w = np.zeros((X.shape[1],1))
        self.gradient_descent(X,y)
        return self

    def optimize(data,tuner_params,n):
        tuner = ModelTuner(CustomRegression,data)
        params = tuner.tune(tuner_params,n)
        model = CustomRegression(**params)
        return model,tuner.log

    def predict(self,X):
        return X.dot(self.w[1:]) + self.w[0]


if __name__ == '__main__':
    from datasets import DataUtility
    from sklearn.metrics import mean_squared_error,r2_score,explained_variance_score

    url = 'https://raw.githubusercontent.com/dri150030/6375/main/power_plant.csv'
    tuner_params = {
            'learning_rate':[0.5,0.1,0.01],
            'max_epochs':[50,300,1000],
            'tolerance':[0.1,0.01,0.001],
            'tol_epochs':[3,10,1000]}

    data = DataUtility(url,['AT','V','AP','RH'],'PE')
    model,log = CustomRegression.optimize(data,tuner_params,10)

    data.resplit()
    model.fit(data.X_train,data.y_train)
    y_pred = model.predict(data.X_test)
    mse = mean_squared_error(data.y_test,y_pred)
    r2 = r2_score(data.y_test,y_pred)
    ev = explained_variance_score(data.y_test,y_pred)

    print('Paramters:',model.params)
    print('Weights:',list(model.w.ravel()))
    print('Mean Squared Test Error',mse)
    print('Coefficient of Determination (R^2):',r2)
    print('Explained Variance:',ev)
