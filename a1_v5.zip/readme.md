## Assignment 1

**Dataset URL**: `https://raw.githubusercontent.com/nishd8/ml_assignment_dataset/main/real_estate.csv` 

**Source** : 
Original Owner and Donor  
Name: Prof. I-Cheng Yeh  
Institutions: Department of Civil Engineering, Tamkang University, Taiwan.

**Information**:
The market historical data set of real estate valuation are collected from Sindian Dist., New Taipei City, Taiwan. The real estate valuation is a regression problem. The data set was randomly split into the training data set (2/3 samples) and the testing data set (1/3 samples).

**Attribute Information:**

The inputs are as follows  
X2=the house age (unit: year)  
X3=the distance to the nearest MRT station (unit: meter)  
X4=the number of convenience stores in the living circle on foot (integer)  
  
The output is as follow  
Y= house price of unit area (10000 New Taiwan Dollar/Ping, where Ping is a local unit, 1 Ping = 3.3 meter squared)

**Directory Structure**:

    Assignment 1
    |-------------- Custom_Linear_Regression.py (Part 1)  
     - A custom class to implement Linear Regression using Gradient Descent
    |-------------- Dataset_Utility.py  
     - A custom class to import and load data from URL/FilePath along with plotting Graphs and calculating accuracy
    |-------------- Report.py  
     - To execute the custom linear regression and output various metrics along with the Sklearn Linear Regression and the Scholastic Gradient Descent

 


**How to run**:
1) Install all the Python Packages using `pip install -r requirements.txt` in the base folder
2) Open Terminal and run `python3 Report.py`