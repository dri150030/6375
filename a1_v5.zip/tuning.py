from itertools import product
from sklearn.metrics import mean_squared_error

class ModelTuner:
    def __init__(self,mclass,data):
        self.mclass = mclass
        self.data = data

    def tune(self,ps,n):
        params = [[(k,v) for v in vs] for k,vs in ps.items()]
        params = list(map(dict,product(*params)))
        train_loss,test_loss,epochs = [0]*len(params),[0]*len(params),[0]*len(params)
        print('Tuning',self.mclass.__name__,'paramters...')
        for t in range(n):
            print('Tuning iteration',t+1,'of',n,'...')
            self.data.resplit()
            for i,kwargs in enumerate(params):
                model = self.mclass(**kwargs)
                model.fit(self.data.X_train,self.data.y_train)
                y_train_pred = model.predict(self.data.X_train)
                y_test_pred = model.predict(self.data.X_test)
                train_loss[i] += mean_squared_error(self.data.y_train,y_train_pred) / n
                test_loss[i] += mean_squared_error(self.data.y_test,y_test_pred) / n
                epochs[i] += model.actual_epochs / n
        self.log = sorted(zip(params,train_loss,test_loss,epochs),key=lambda x: x[2])
        return self.log[0][0]
