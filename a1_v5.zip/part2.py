import numpy as np
from tuning import ModelTuner
from sklearn.linear_model import SGDRegressor
from sklearn.utils._testing import ignore_warnings
from sklearn.exceptions import ConvergenceWarning

class SKLRegression:
    def __init__(self,**kwargs):
        self.params = {'max_epochs':1000,'learning_schedule':'invscaling',
                'learning_rate':0.01,'tolerance':0.001,'tol_epochs':5}
        for k in self.params:
            if k in kwargs:
                self.params[k] = kwargs[k]
        sgdparams = {'max_iter':self.params['max_epochs'],'learning_rate':self.params['learning_schedule'],
                'eta0':self.params['learning_rate'],'tol':self.params['tolerance'],
                'n_iter_no_change':self.params['tol_epochs']}
        self.model = SGDRegressor(**sgdparams)

    def __repr__(self):
        return '<SKLRegression object: ' \
                'Parameters ' + str(self.params) + ', Weights ' + str(list(self.w.ravel())) + '>'

    @ignore_warnings(category=ConvergenceWarning)
    def fit(self,X,y):
        self.model.fit(X,y.ravel())
        self.w = np.reshape(np.append(self.model.intercept_,self.model.coef_),(X.shape[1]+1,1))
        self.actual_epochs = self.model.n_iter_

    def optimize(data,tuner_params,n):
        tuner = ModelTuner(SKLRegression,data)
        params = tuner.tune(tuner_params,n)
        model = SKLRegression(**params)
        return model,tuner.log
    
    def predict(self,X):
        return self.model.predict(X)

if __name__ == '__main__':
    from datasets import DataUtility
    from sklearn.metrics import mean_squared_error,r2_score,explained_variance_score

    url = 'https://raw.githubusercontent.com/dri150030/6375/main/power_plant.csv'
    tuner_params = {
            'learning_schedule':['constant','invscaling','adaptive'],
            'learning_rate':[0.5,0.1,0.01],
            'max_epochs':[50,300,1000],
            'tolerance':[0.1,0.01,0.001],
            'tol_epochs':[3,10,1000]}

    data = DataUtility(url,['AT','V','AP','RH'],'PE')
    model,log = SKLRegression.optimize(data,tuner_params,10)

    data.resplit()
    model.fit(data.X_train,data.y_train)
    y_pred = model.predict(data.X_test)
    mse = mean_squared_error(data.y_test,y_pred)
    r2 = r2_score(data.y_test,y_pred)
    ev = explained_variance_score(data.y_test,y_pred)

    print('Paramters:',model.params)
    print('Weights:',list(model.w.ravel()))
    print('Mean Squared Test Error',mse)
    print('Coefficient of Determination (R^2):',r2)
    print('Explained Variance:',ev)
