
import numpy as np
import pandas as pd
from datasets import DataUtility
from part1 import CustomRegression
from part2 import SKLRegression
from tuning import ModelTuner
from sklearn.linear_model import LinearRegression,SGDRegressor
from sklearn.metrics import mean_squared_error,r2_score,explained_variance_score
import matplotlib.pyplot as plt

col_description = {'AT':'Ambient Temperature (Celsius)','V':'Exhaust Vacuum (cm Hg)',
        'AP':'Ambient Pressure (milibar)','RH':'Relative Humidity (%)','PE':'Energy Output (MW)'}

def plot_features(data,y_pred,title,alpha):
    for i,f in enumerate(data.X_labels):
        plt.scatter(data.X_test_raw[:,i],data.y_test,color='green',alpha=alpha,label='Actual Value')
        plt.scatter(data.X_test_raw[:,i],y_pred,color='blue',alpha=alpha,label='Predicted Value')
        plt.title(title)
        plt.xlabel(col_description[f])
        plt.ylabel(col_description[data.y_label])
        plt.legend()
        plt.show()
        plt.cla()

def line(self,x,y,title,xlabel,ylabel):
    plt.plot(x,y,color='blue')
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.show()
    plt.cla()

def epoch_mse(data,mclass,sched,rate,epochs):
    model = mclass(learning_schedule=sched,learning_rate=rate,max_epochs=epochs,tol_epochs=epochs)
    model.fit(data.X_train,data.y_train)
    return mean_squared_error(data.y_test,model.predict(data.X_test))

url = 'https://raw.githubusercontent.com/dri150030/6375/main/power_plant.csv'
inputs,output = ['AT','AP','RH','V'],'PE'
data = DataUtility(url,inputs,output)

tuner_params = {
        'learning_rate':[0.3,0.1,0.05],
        'max_epochs':[50,300,1000],
        'tolerance':[0.1,0.01,0.001],
        'tol_epochs':[3,10,1000]}

y_pred = CustomRegression().fit(data.X_train,data.y_train).predict(data.X_test)
plot_features(data,y_pred,'CustomRegression Predicted vs Actual Output',0.1)

# Epochs vs MSE for constant learning rate
x,cy3,cy1,cy05,sy3,sy1,sy05 = [10,20,30,40,50,60,70,80,90,100],[],[],[],[],[],[]
for e in x:
    cy3.append(epoch_mse(data,CustomRegression,'',0.3,e))
    sy3.append(epoch_mse(data,SKLRegression,'constant',0.3,e))
    cy1.append(epoch_mse(data,CustomRegression,'',0.1,e))
    sy1.append(epoch_mse(data,SKLRegression,'constant',0.1,e))
    cy05.append(epoch_mse(data,CustomRegression,'',0.05,e))
    sy05.append(epoch_mse(data,SKLRegression,'constant',0.05,e))

# Epochs vs MSE for SKLRegression with invscaling and adaptive learning rate
syi,sya = [],[]
for e in x:
    syi.append(epoch_mse(data,SKLRegression,'invscaling',0.01,e))
    sya.append(epoch_mse(data,SKLRegression,'adaptive',0.01,e))

#data.line(x,y,'Epochs vs MSE','Epochs','Mean Squared Error')
cp5 = plt.plot(x,syi,color='blue',label='CustomRegression')
sp5 = plt.plot(x,sya,color='green',label='SKLRegression')
plt.title('Epochs vs MSE, Learning Rate = 0.1')
plt.xlabel('Epochs')
plt.ylabel('MSE')
plt.legend()
plt.show()
plt.cla()






exit()
p = ctune.params
p = [params|{'train_loss':train,'test_loss':test,'epochs':epoch} for params,train,test,epoch in p]
df = pd.DataFrame(p)
df.to_latex('doc/tbl.tex',float_format='%.3f',longtable=True,index=False)
