import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np


class DataUtility():
    def __init__(self,url,inputs,output,test_ratio=0.2):
        df = pd.read_csv(url)
        self.X_labels,self.y_label = inputs,output
        self.X,self.y = df[inputs].to_numpy(),df[[output]].to_numpy()
        self.scaler = StandardScaler()
        self.resplit(test_ratio)

    def resplit(self,test_ratio=0.2):
        self.X_train_raw,self.X_test_raw,self.y_train,self.y_test = train_test_split(self.X,self.y,test_size=test_ratio)
        #self.X_train = np.append(np.ones((self.X_train.shape[0],1)),self._scaler.fit_transform(self.X_train),axis=1)
        #self.X_test = np.append(np.ones((self.X_test.shape[0],1)),self._scaler.transform(self.X_test),axis=1)
        self.X_train = self.scaler.fit_transform(self.X_train_raw)
        self.X_test = self.scaler.transform(self.X_test_raw)
        
    def scatter(self,x,y,xlabel,ylabel):
        plt.scatter(x,y,color='blue')
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()
        plt.cla()

    def scatter_pred(self,x,y_true,y_pred,title,xlabel,ylabel,alpha):
        scat_true = plt.scatter(x,y_true,color='blue',alpha=alpha)
        scat_pred = plt.scatter(x,y_pred,color='green',alpha=alpha)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.legend([scat_true,scat_pred],['Predicted','Actual'])
        plt.show()
        plt.cla()

    def line(self,x,y,title,xlabel,ylabel):
        scat_true = plt.plot(x,y,color='blue')
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()
        plt.cla()

    def plot_graph_distance_to_rail(self,Y_pred,X_test,y_test):
        scat_pred = plt.scatter(X_test[:,1],Y_pred,label='Predicted',color='green')
        scat_act = plt.scatter(X_test[:,1],y_test,label='Actual', color='blue')
        plt.legend([scat_act,scat_pred],['Predicted','Actual'])
        plt.xlabel('Distance to Rail')
        plt.ylabel('Price Per Unit Area')
        plt.show()

    def plot_graph_number_of_stores(self,Y_pred,X_test,y_test):
        scat_pred = plt.scatter(X_test[:,2],Y_pred,label='Predicted',color='green')
        scat_act = plt.scatter(X_test[:,2],y_test,label='Actual', color='blue')
        plt.legend([scat_act,scat_pred],['Predicted','Actual'])
        plt.xlabel('Number of Stores')
        plt.ylabel('Price Per Unit Area')
        plt.show()
