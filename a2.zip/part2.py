import numpy as np
import pandas as pd
from itertools import product
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import log_loss

class NeuralNet:
    def __init__(self,url,inputs,outputs):
        # read csv from url and read feature/output cols into numpy arrays
        df = pd.read_csv(url)
        self.X,self.y = df[inputs].to_numpy(),df[outputs].to_numpy().ravel()

    def preprocess(self):
        # scale input features and make train/test split
        self.X = StandardScaler().fit_transform(self.X)
        self.classes = np.unique(self.y)
        self.classes.sort()
        self.X_train,self.X_test,self.y_train,self.y_test = train_test_split(self.X,self.y,test_size=0.1)

    def train_evaluate(self,params):
        # take list of param choices and generate list of param keyword arg dictionaries
        params = [[(k,v) for v in vs] for k,vs in params.items()]
        params = list(map(dict,product(*params)))
        self.histories = [[] for _ in params]
        self.table = [dict(p) for p in params]

        # train each model and record train/test accuracy/loss
        for i in range(len(params)):
            print('Training model',i+1,'of',len(params),'...')
            model = MLPClassifier(**params[i],
                    learning_rate='constant',early_stopping=False,n_iter_no_change=params[i]['max_iter'])

            for _ in range(params[i]['max_iter']):
                model.partial_fit(self.X_train,self.y_train,classes=self.classes)
                self.histories[i].append(model.score(self.X_train,self.y_train))

            self.table[i]['train_accuracy'] = model.score(self.X_train,self.y_train)
            self.table[i]['test_accuracy'] = model.score(self.X_test,self.y_test)
            self.table[i]['train_error'] = log_loss(self.y_train,model.predict_proba(self.X_train))
            self.table[i]['test_error'] = log_loss(self.y_test,model.predict_proba(self.X_test))
            print(self.table[i])

        self.table = pd.DataFrame(self.table)
        print('Done')
    

if __name__ == "__main__":
    url = 'https://raw.githubusercontent.com/dri150030/6375/main/beans.csv'
    inputs = ['Area','Perimeter','MajorAxisLength','MinorAxisLength','AspectRation','Eccentricity','ConvexArea',
            'EquivDiameter','Extent','Solidity','roundness','Compactness','ShapeFactor1','ShapeFactor2',
            'ShapeFactor3','ShapeFactor4']
    outputs = ['Class']
    params = {
            'activation':['logistic','tanh','relu'],
            'learning_rate_init':[0.01,0.1],
            'max_iter':[100,200],
            'hidden_layer_sizes':[(100,100),(100,100,100)]}

    net = NeuralNet(url,inputs,outputs)
    net.preprocess()
    net.train_evaluate(params)

    print('Model Results:')
    print(net.table)

    # draw plots for training history
    import matplotlib.pyplot as plt
    from random import random

    plt.figure(figsize=(8,8))
    plt.title('Model Accuracy vs Training Epochs\n(100 Epoch Models)')
    plt.xlabel('Training Epochs')
    plt.ylabel('Model Accuracy')
    plt.yticks([x/100 for x in range(0,101,5)])
    plt.hlines([x/100 for x in range(0,101,5)],0,100,linestyles='dotted',colors='black')
    for i,history in enumerate(net.histories):
        if len(history) == 100:
            plt.plot(history,color=(random(),random(),random()),label=i)
    plt.legend()
    plt.savefig('out/hist100.png',dpi=200)
    plt.clf()

    plt.figure(figsize=(8,8))
    plt.title('Model Accuracy vs Training Epochs\n(200 Epoch Models)')
    plt.xlabel('Training Epochs')
    plt.ylabel('Model Accuracy')
    plt.yticks([x/100 for x in range(0,101,5)])
    plt.hlines([x/100 for x in range(0,101,5)],0,200,linestyles='dotted',colors='black')
    for i,history in enumerate(net.histories):
        if len(history) == 200:
            plt.plot(history,color=(random(),random(),random()),label=i)
    plt.legend()
    plt.savefig('out/hist200.png',dpi=200)

    # create table for model results
    net.table = net.table.rename(columns={'activation':'Activation','learning_rate_init':'Learning Rate',
        'hidden_layer_sizes':'Hidden Layers','max_iter':'Epochs','train_accuracy':'Train Accuracy',
        'test_accuracy':'Test Accuracy','train_error':'Train Error','test_error':'Test Error'})
    net.table.to_latex('out/tbl.tex',longtable=True,float_format='%.5f')
